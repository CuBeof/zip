<template>
  <div class="flex flex-wrap mt-4">
    <div class="w-full mb-12 px-4">
      <CardList :tableName="'List Category'" :data="category" :link="'/category'"/>
    </div>
  </div>
</template>
<script>
import CardList from "@/components/Cards/CardList.vue";

export default {
data: () => ({
      category: []
  }),
  components: {
    CardList,
  },
  mounted(){
    this.category = [
    {
        "id": 8,
        "name": "IS関係製品/サービス"
    },
    {
        "id": 12,
        "name": "その他"
    },
    {
        "id": 3,
        "name": "レンタル"
    },
    {
        "id": 5,
        "name": "医療サービス"
    },
    {
        "id": 4,
        "name": "印刷"
    },
    {
        "id": 2,
        "name": "教育/訓練"
    },
    {
        "id": 7,
        "name": "校正/測定/検定"
    },
    {
        "id": 6,
        "name": "検討中"
    },
    {
        "id": 1,
        "name": "物品購入"
    },
    {
        "id": 9,
        "name": "翻訳・公証"
    },
    {
        "id": 11,
        "name": "衛星/掃除"
    },
    {
        "id": 10,
        "name": "輸送サービス"
    }
]
  }
}
</script>
