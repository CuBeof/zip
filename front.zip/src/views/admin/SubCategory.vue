<template>
  <div class="flex flex-wrap mt-4">
    <div class="w-full mb-12 px-4">
      <CardList :tableName="category.name" :data="category.subCategory" :link="'/subcategory'"/>
    </div>
  </div>
</template>
<script>
import CardList from "@/components/Cards/CardList.vue";

export default {
data: () => ({
      category: {}
  }),
  components: {
    CardList,
  },
  mounted(){
    this.category = {
      "id": 1,
      "name": "物品購入",
      "subCategory": [
          {
              "id": 1,
              "name": "文房具"
          },
          {
              "id": 2,
              "name": "HTCの設備/部品/消耗品"
          },
          {
              "id": 3,
              "name": "事務設備"
          },
          {
              "id": 4,
              "name": "食品"
          },
          {
              "id": 5,
              "name": "プレゼント"
          },
          {
              "id": 6,
              "name": "医薬品/薬"
          },
          {
              "id": 7,
              "name": "化学品"
          }
      ]
  }
  console.log(this.category.name)
  }
}
</script>
