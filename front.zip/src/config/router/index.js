// layouts

import Admin from "@/layouts/Admin.vue";
import Auth from "@/layouts/Auth.vue";

// views for Admin layout

import Dashboard from "@/views/admin/Dashboard.vue";
import Settings from "@/views/admin/Settings.vue";
import Tables from "@/views/admin/Tables.vue";
import Maps from "@/views/admin/Maps.vue";
import Category from "@/views/admin/Category.vue";
import SubCategory from "@/views/admin/SubCategory.vue";

// views for Auth layout

import Login from "@/views/auth/Login.vue";
import Register from "@/views/auth/Register.vue";

// views without layouts

import Landing from "@/views/Landing.vue";
import Profile from "@/views/Profile.vue";
// import Index from "@/views/Index.vue";

const routes = [
    {
      path: "/",
      redirect: "/dashboard",
      component: Admin,
      children: [
        {
          path: "/dashboard",
          component: Dashboard,
        },
        {
          path: "/settings",
          component: Settings,
        },
        {
          path: "/tables",
          component: Tables,
        },
        {
          path: "/maps",
          component: Maps,
        },
        {
          path: "/category",
          component: Category,
        },
        {
          path: "/category/:id",
          component: SubCategory,
        },
      ],
    },
    {
      path: "/auth",
      redirect: "/auth/login",
      component: Auth,
      children: [
        {
          path: "/auth/login",
          component: Login,
        },
        {
          path: "/auth/register",
          component: Register,
        },
      ],
    },
    {
      path: "/landing",
      component: Landing,
    },
    {
      path: "/profile",
      component: Profile,
    },

    { path: "*", redirect: "/" },
  ];
  
  export default routes;