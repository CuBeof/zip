<template>
  <div class="bg-gray-200 relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded">
    <div class="bg-white rounded-t mb-0 px-4 py-3 border-0">
      <div class="flex flex-wrap items-center">
        <div class="relative w-full px-4 max-w-full flex-grow flex-1">
          <h3 class="font-semibold text-lg text-gray-800">
            {{tableName}}
          </h3>
        </div>
      </div>
    </div>
    <div v-if="!data" class="fa-3x mx-auto">
    <i class="fas fa-spinner fa-pulse"></i>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
      <!-- Card -->
      <div v-for="item in data" :key="item.id"  class="flex items-center m-4 p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
          <div class="p-3 mr-4 text-orange-500 bg-orange-100 rounded-full dark:text-orange-100 dark:bg-orange-500">
            <i class="fa fa-list-alt" aria-hidden="true"></i>
          </div>
          <div>
            <router-link :to="link + '/' + item.id">
            <p class="m-2 font-semibold text-gray-600 dark:text-gray-400">
              {{item.name}}
            </p>
         </router-link>
          </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    data:{},
    tableName:{
      default: "Name: "
    },
    link: {
      default: ""
    }
  }
};
</script>
