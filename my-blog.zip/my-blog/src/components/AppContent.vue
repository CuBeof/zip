<template>
    <v-main class="box">
        <router-view/>
    </v-main>
</template>

<script>
export default {
}
</script>