<template>
    <v-progress-linear
        color="deep-purple accent-4"
        indeterminate
        rounded
    ></v-progress-linear>
</template>