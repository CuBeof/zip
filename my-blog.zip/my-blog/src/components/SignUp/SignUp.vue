<template>
    <div class="mini-box">
        <p>Doan van dai vcl ra day nay cac Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vitae sint officiis id incidunt culpa possimus dolorum veniam doloremque fugit quam deleniti obcaecati ratione aut repudiandae, molestias animi dicta accusamus voluptates?</p>
    </div>
</template>

<script>
export default {
    name: 'SignUp'
}
</script>
<style scoped>
.mini-box {
	max-width: 420px;
	width: 100%
}
</style>