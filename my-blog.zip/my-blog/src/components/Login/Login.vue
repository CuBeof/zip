<template>
    <div class="wrapper mini-box">
        <v-card>
            <v-img
                height="200px"
                class="white--text align-center"
                lazy-src="https://source.unsplash.com/random/"
            >
            <v-card-title primary-title class="layout justify-center">WELCOME BACK</v-card-title>
            </v-img>
            <v-form
            ref="form"
            v-model="valid"
            :lazy-validation="lazy"
            class="pa-6"
            >
                <v-text-field
                    outlined
                    clearable
                    label="Nhập email"
                    prepend-inner-icon="email"
                    name="email"
                ></v-text-field>
                 <v-text-field
                    v-model="password"
                    outlined
                    label="Nhập mật khẩu"
                    prepend-inner-icon="lock"
                    :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
                    :type="showPassword ? 'text' : 'password'"
                    @click:append="showPassword = !showPassword"
                    name="password"
                ></v-text-field>
                <v-btn class="ma-2" tile outlined color="success">
                    <v-icon left>mdi-pencil</v-icon> Edit
                </v-btn>
                <v-btn
                    outlined
                    :loading="loading3"
                    :disabled="loading3"
                    @click="clickLoginButton"
                    >
                    Login
                    <v-icon right>mdi-login</v-icon>
                    </v-btn>
            </v-form>
        </v-card>
    </div>
</template>

<script>
export default {
    name: 'Login',
    data: () => ({
        showPassword: false,
        password: '',
        loading3: false,
  }),
  watch: {
      clickLoginButton () {
        this.loading3 = true
      },
  },
}
</script>
<style scoped>
.wrapper {
    margin-left: auto;
    margin-right: auto;
    padding-top: 2rem;
    padding-bottom: 2rem;
    position: relative;
    z-index: 1;
}
.mini-box {
	max-width: 420px;
	width: 100%
}

/* Login Button */
 .custom-loader {
    animation: loader 1s infinite;
    display: flex;
  }
  @-moz-keyframes loader {
    from {
      transform: rotate(0);
    }
    to {
      transform: rotate(360deg);
    }
  }
  @-webkit-keyframes loader {
    from {
      transform: rotate(0);
    }
    to {
      transform: rotate(360deg);
    }
  }
  @-o-keyframes loader {
    from {
      transform: rotate(0);
    }
    to {
      transform: rotate(360deg);
    }
  }
  @keyframes loader {
    from {
      transform: rotate(0);
    }
    to {
      transform: rotate(360deg);
    }
  }
</style>