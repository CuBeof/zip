package vn.va.entities;

import org.apache.solr.analysis.LowerCaseFilterFactory;
import org.apache.solr.analysis.SnowballPorterFilterFactory;
import org.apache.solr.analysis.StandardTokenizerFactory;
import org.hibernate.search.annotations.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * Created by nguyen.viet.anhc on 29/11/2016.
 */
@Entity
@Indexed
@Table(name = "demofts.book")
public class Book {
	@Id
	@Column(name = "book_id")
	private Integer bookId;

	@Column(name = "title", nullable= false, length = 128)
	@Field(index= Index.YES, analyze= Analyze.YES, store= Store.NO)
	private String title;

	@Column(name = "description", nullable= false, length = 256)
	@Field(index=Index.YES, analyze=Analyze.YES, store=Store.NO)
	private String description;

	@Column(name = "author", nullable= false, length = 64)
	@Field(index=Index.YES, analyze=Analyze.YES, store=Store.NO)
	private String author;

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
}
