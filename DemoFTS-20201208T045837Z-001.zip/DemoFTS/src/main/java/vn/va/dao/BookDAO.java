package vn.va.dao;

import vn.va.entities.Book;

import java.util.List;

/**
 * Created by nguyen.viet.anhc on 29/11/2016.
 */
public interface BookDAO {
	void indexBooks() throws Exception;

	void addBook(String bookTitle, String bookDescription, String bookAuthor);

	List<Book> search(String keyword);
}
