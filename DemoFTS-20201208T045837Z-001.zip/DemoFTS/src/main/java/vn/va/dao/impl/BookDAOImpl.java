package vn.va.dao.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import vn.va.dao.BookDAO;
import vn.va.entities.Book;
import java.util.List;

/**
 * Created by nguyen.viet.anhc on 29/11/2016.
 */
@Repository
@Transactional
public class BookDAOImpl implements BookDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void indexBooks() throws Exception {
		try {
			Session session = sessionFactory.getCurrentSession();
			FullTextSession fullTextSession = Search.getFullTextSession(session);
			fullTextSession.createIndexer().startAndWait();
		} catch(Exception e) {
			throw e;
		}
	}

	@Override
	public void addBook(String bookTitle, String bookDescription, String bookAuthor) {
		Book book = new Book();
		book.setAuthor(bookAuthor);
		book.setDescription(bookDescription);
		book.setTitle(bookTitle);
		sessionFactory.getCurrentSession().save(book);
	}

	@Override
	public List<Book> search(String keyword) {
		Session session = sessionFactory.getCurrentSession();

		FullTextSession fullTextSession = Search.getFullTextSession(session);

		QueryBuilder qb = fullTextSession.getSearchFactory()
				.buildQueryBuilder().forEntity(Book.class).get();
		org.apache.lucene.search.Query query = qb
				.keyword().onFields("description", "title", "author")
				.matching(keyword)
				.createQuery();

		org.hibernate.Query hibQuery =
				fullTextSession.createFullTextQuery(query, Book.class);

		List<Book> results = hibQuery.list();
		return results;
	}
}
