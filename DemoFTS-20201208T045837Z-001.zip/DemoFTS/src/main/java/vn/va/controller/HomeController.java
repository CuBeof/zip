package vn.va.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import vn.va.dao.BookDAO;
import vn.va.entities.Book;

import javax.annotation.PostConstruct;
import java.util.Date;
import java.util.List;

/**
 * Created by nguyen.viet.anhc on 28/11/2016.
 */
@Controller
public class HomeController {
	@Autowired
	BookDAO bookDAO;

	@ResponseBody
	@RequestMapping(value = "/indexData", method = RequestMethod.GET)
	public String indexData() {
		try {
			bookDAO.indexBooks();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Indexed at " + new Date().toGMTString();
	}

	@ResponseBody
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public List<Book> search(@RequestParam(value = "keyword") String keyword) {
		return bookDAO.search(keyword);
	}
}
