package natv.ag0.entities;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonManagedReference;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.search.annotations.Indexed;

import javax.persistence.*;
import java.util.List;
import java.util.List;

@Entity
@Indexed
@Table(name = "koubaiapp.categories")
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class Category {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(name = "name")
    private String name;

    @JsonIgnore
    @OneToMany(mappedBy = "parent", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<SubCategory> sub_category;

    public Category() {}
    public Category(Integer id) {
        this.id = id;
    }
    public Category(String name) {
        this.name = name;
    }
    public Category(Integer id, String name) {
        this.id = id;
        this.name = name;
    }


    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }


    public List<SubCategory> getSubCategory() {
        return sub_category;
    }
    public void setSubCategory(List<SubCategory> sub_category) {
        this.sub_category = sub_category;
    }
}
