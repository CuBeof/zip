package natv.ag0.entities;

import org.apache.solr.analysis.*;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonManagedReference;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.search.annotations.*;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Indexed
@Table(name = "koubaiapp.vendors")
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class Vendor {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Field
    private String name;
    @Field
    private String person_in_charge;
    @Field
    private String telephone_number;
    @Field
    private String website;
    @Field
    private String mobile_number;
    @Field
    private String email;
    @Field
    private String address;

    @Temporal(TemporalType.TIMESTAMP)
    private Date establish_year;
    private Integer number_of_employees;
    private String branch;

    @Temporal(TemporalType.TIMESTAMP)
    private Date date_of_issue;

    @JsonIgnore
    @OneToMany(mappedBy = "vendor", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Order> order;

    public Vendor() {}
    public Vendor(Integer id) {
        this.id = id;
    }
    public Vendor(String name) {
        this.name = name;
    }


    public Vendor(Integer id, String name, String person_in_charge,
                  String telephone_number, String website, String mobile_number,
                  String email, String address, Date establish_year,
                  Integer number_of_employees, String branch, Date date_of_issue) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.person_in_charge = person_in_charge;
        this.telephone_number = telephone_number;
        this.website = website;
        this.mobile_number = mobile_number;
        this.email = email;
        this.establish_year = establish_year;
        this.number_of_employees = number_of_employees;
        this.branch = branch;
        this.date_of_issue = date_of_issue;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPerson_in_charge() {
        return person_in_charge;
    }

    public String getTelephone_number() {
        return telephone_number;
    }

    public String getWebsite() {
        return website;
    }

    public String getMobile_number() {
        return mobile_number;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public Date getEstablish_year() {
        return establish_year;
    }

    public Integer getNumber_of_employees() {
        return number_of_employees;
    }

    public String getBranch() {
        return branch;
    }

    public Date getDate_of_issue() {
        return date_of_issue;
    }

    public List<Order> getOrder() {
        return order;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPerson_in_charge(String person_in_charge) {
        this.person_in_charge = person_in_charge;
    }

    public void setTelephone_number(String telephone_number) {
        this.telephone_number = telephone_number;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setEstablish_year(Date establish_year) {
        this.establish_year = establish_year;
    }

    public void setNumber_of_employees(Integer number_of_employees) {
        this.number_of_employees = number_of_employees;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public void setDate_of_issue(Date date_of_issue) {
        this.date_of_issue = date_of_issue;
    }

    public void setOrder(List<Order> order) {
        this.order = order;
    }
}
