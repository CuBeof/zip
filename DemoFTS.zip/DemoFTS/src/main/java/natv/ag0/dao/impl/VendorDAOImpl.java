package natv.ag0.dao.impl;

import natv.ag0.dao.VendorDAO;
import natv.ag0.entities.Vendor;
import natv.ag0.entities.Vendor;
import natv.ag0.utils.MyNotify;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
@Transactional
public class VendorDAOImpl implements VendorDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public Vendor getVendorById(Integer id) {
		Session session = sessionFactory.getCurrentSession();
		Vendor result = (Vendor) session.get(Vendor.class, id);
		return  result;
	}

	public MyNotify createVendor(Vendor vendor) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		try {
			session.save(vendor);
			session.getTransaction().commit();
			response.setType("success");
			response.setMessage("Vendor has been created!");
		} catch (Exception e){
			response.setType("error");
			response.setMessage(e.getMessage());
		}
		return response;
	}

	public MyNotify updateVendor(Vendor vendor) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		try {
			session.update(vendor);
			session.getTransaction().commit();
			response.setType("success");
			response.setMessage("Vendor has been updated!");
		} catch (Exception e){
			response.setType("error");
			response.setMessage(e.getMessage());
		}
		return response;
	}

	public MyNotify deleteVendor(Vendor vendor) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		Object isVendorExist = session.get(Vendor.class, vendor.getId());
		if (null == isVendorExist) {
			response.setType("error");
			response.setMessage("Can't delete this Vendor. Vendor with id:" + vendor.getId() + " is not found on database.");
		} else {
			try {
				session.delete(vendor);
				response.setType("success");
				response.setMessage("Vendor  has been deleted!");
			} catch (Exception e){
				response.setType("error");
				response.setMessage(e.getMessage());
			}
		}
		return response;
	}

	public List<Vendor> searchVendor(String keyword, Integer offset, Integer maxResults){
		Session session = sessionFactory.getCurrentSession();

		FullTextSession fullTextSession = Search.getFullTextSession(session);

		QueryBuilder qb = fullTextSession.getSearchFactory()
				.buildQueryBuilder().forEntity(Vendor.class).get();
		org.apache.lucene.search.Query query = qb
				.keyword().onFields("name", "person_in_charge", "telephone_number", "website", "mobile_number", "email", "address")
				.matching(keyword)
				.createQuery();

		org.hibernate.search.FullTextQuery hibQuery =
				fullTextSession.createFullTextQuery(query, Vendor.class);

		org.apache.lucene.search.Sort sort = new Sort(
				new SortField("id", SortField.SCORE));

		hibQuery.setSort(sort);
		List<Vendor>  results = null;
		try {
			results = hibQuery
					.setFirstResult(offset != null ? offset * 20 - 20 : 0)
					.setMaxResults(20)
					.list();
		} catch (Exception e){
//			Do Nothing
		}
		return results;
	}
}