package natv.ag0.dao;

import natv.ag0.entities.Order;
import natv.ag0.utils.MyNotify;

import java.util.List;

public interface OrderDAO {
	Order getOrderById(Integer id);
	List<Order> getAllOrder();
	List<Order> getOrderBySubCategoryId(Integer sub_category_id);
	List<Order> getOrderByVendorId(Integer vendor_id);
	MyNotify createOrder(Order Order);
	MyNotify updateOrder(Order Order);
	MyNotify deleteOrder(Order Order);
	public List<Order> searchOrder(String keyword, Integer offset, Integer maxResults);
}
