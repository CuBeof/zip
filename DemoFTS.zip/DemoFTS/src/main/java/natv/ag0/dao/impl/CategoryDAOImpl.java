package natv.ag0.dao.impl;

import natv.ag0.dao.CategoryDAO;
import natv.ag0.entities.Category;
import natv.ag0.utils.MyNotify;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class CategoryDAOImpl implements CategoryDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public Category getCategoryById(Integer id) {
		Session session = sessionFactory.getCurrentSession();
		Category result = (Category) session.get(Category.class, id);
		if (result != null) {
			Hibernate.initialize(result.getSubCategory());
		}
		return  result;
	}

	public List<Category> getAllCategory() {
		Session session = sessionFactory.getCurrentSession();
		List<Category> result = session.createCriteria(Category.class).list();
		for (Category category: result) {
			category.setSubCategory(null);
		}
		return  result;
	}

	public MyNotify createCategory(Category category) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		try {
			session.save(category);
			session.getTransaction().commit();
			response.setType("success");
			response.setMessage(category.getName() + " has been created!");
		} catch (Exception e){
			response.setType("error");
			response.setMessage(e.getMessage());
		}
		return response;
	}

	public MyNotify updateCategory(Category category) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		try {
			session.update(category);
			session.getTransaction().commit();
			response.setType("success");
			response.setMessage(category.getName() + " has been updated!");
		} catch (Exception e){
			response.setType("error");
			response.setMessage(e.getMessage());
		}
		return response;
	}

	public MyNotify deleteCategory(Category category) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		try {
			session.delete(category);
			session.getTransaction().commit();
			response.setType("success");
			response.setMessage(category.getName() + " has been deleted!");
		} catch (Exception e){
			response.setType("error");
			response.setMessage(e.getMessage());
		}
		return response;
	}
}