package natv.ag0.dao.impl;

import natv.ag0.dao.SubCategoryDAO;
import natv.ag0.entities.Category;
import natv.ag0.entities.SubCategory;
import natv.ag0.utils.MyNotify;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by nguyen.viet.anhc on 29/11/2016.
 */
@Repository
@Transactional
public class SubCategoryDAOImpl implements SubCategoryDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public SubCategory getSubCategoryById(Integer id) {
        Session session = sessionFactory.getCurrentSession();
        SubCategory result = (SubCategory) session.get(SubCategory.class, id);
        if (result != null) {
            Hibernate.initialize(result.getParent());
        }
        return  result;
    }

    public List<SubCategory> getSubCategoryByParentId(Integer parent_id) {
        Session session = sessionFactory.getCurrentSession();
        List<SubCategory> result = session.createCriteria(SubCategory.class)
                .add(Restrictions.eq("parent.id", parent_id))
                .list();
        return  result;
    }

    public MyNotify createSubCategory(SubCategory subCategory) {
        MyNotify response = new MyNotify();
        Session session = sessionFactory.getCurrentSession();
        try {
            session.save(subCategory);
            session.getTransaction().commit();
            response.setType("success");
            response.setMessage(subCategory.getName() + " has been created!");
        } catch (Exception e){
            response.setType("error");
            response.setMessage(e.getMessage());
        }
        return response;
    }

    public MyNotify updateSubCategory(SubCategory subCategory) {
        MyNotify response = new MyNotify();
        Session session = sessionFactory.getCurrentSession();
        try {
            session.update(subCategory);
            session.getTransaction().commit();
            response.setType("success");
            response.setMessage(subCategory.getName() + " has been updated!");
        } catch (Exception e){
            response.setType("error");
            response.setMessage(e.getMessage());
        }
        return response;
    }

    public MyNotify deleteSubCategory(SubCategory subCategory) {
        MyNotify response = new MyNotify();
        Session session = sessionFactory.getCurrentSession();
        try {
            session.delete(subCategory);
            session.getTransaction().commit();
            response.setType("success");
            response.setMessage(subCategory.getName() + " has been deleted!");
        } catch (Exception e){
            response.setType("error");
            response.setMessage(e.getMessage());
        }
        return response;
    }
}