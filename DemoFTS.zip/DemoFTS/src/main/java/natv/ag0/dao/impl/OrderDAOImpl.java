package natv.ag0.dao.impl;

import natv.ag0.dao.OrderDAO;
import natv.ag0.entities.Order;
import natv.ag0.entities.SubCategory;
import natv.ag0.utils.MyNotify;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StaleStateException;
import org.hibernate.criterion.Restrictions;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
@Transactional
public class OrderDAOImpl implements OrderDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public Order getOrderById(Integer id) {
		Session session = sessionFactory.getCurrentSession();
		Order result = (Order) session.get(Order.class, id);
		return  result;
	}

	public List<Order> getAllOrder() {
		Session session = sessionFactory.getCurrentSession();
		List<Order> result = session.createCriteria(Order.class).list();
		return  result;
	}

	public List<Order> getOrderBySubCategoryId(Integer sub_category_id) {
		Session session = sessionFactory.getCurrentSession();
		List<Order> result = session.createCriteria(Order.class)
				.add(Restrictions.eq("sub_category.id", sub_category_id))
				.list();
		return  result;
	}

	public List<Order> getOrderByVendorId(Integer vendor_id) {
		Session session = sessionFactory.getCurrentSession();
		List<Order> result = session.createCriteria(Order.class)
				.add(Restrictions.eq("vendor.id", vendor_id))
				.list();
		return  result;
	}

	public MyNotify createOrder(Order order) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		try {
			session.save(order);
			session.getTransaction().commit();
			response.setType("success");
			response.setMessage("Order has been created!");
		} catch (Exception e){
			response.setType("error");
			response.setMessage(e.getMessage());
		}
		return response;
	}

	public MyNotify updateOrder(Order order) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		try {
			session.update(order);
			session.getTransaction().commit();
			response.setType("success");
			response.setMessage("Order  has been updated!");
		} catch (Exception e){
			response.setType("error");
			response.setMessage(e.getMessage());
		}
		return response;
	}

	public MyNotify deleteOrder(Order order) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		Object isOrderExist = session.get(Order.class, order.getId());
		if (null == isOrderExist) {
			response.setType("error");
			response.setMessage("Can't delete this order. Order with id:" + order.getId() + " is not found on database.");
		} else {
			try {
				session.delete(order);
				response.setType("success");
				response.setMessage("Order  has been deleted!");
			} catch (Exception e){
				response.setType("error");
				response.setMessage(e.getMessage());
			}
		}
		return response;
	}

	public List<Order> searchOrder(String keyword, Integer offset, Integer maxResults){
		Session session = sessionFactory.getCurrentSession();

		FullTextSession fullTextSession = Search.getFullTextSession(session);

		QueryBuilder qb = fullTextSession.getSearchFactory()
				.buildQueryBuilder().forEntity(Order.class).get();
		org.apache.lucene.search.Query query = qb
				.keyword().onFields("request_department", "request_group", "case_number", "description", "description_vn", "maker", "model")
				.matching(keyword)
				.createQuery();

		org.hibernate.Query hibQuery =
				fullTextSession.createFullTextQuery(query, Order.class);

		List<Order> results = hibQuery
				.setFirstResult(offset!=null?offset*20:0)
				.setMaxResults(20)
				.list();
		return results;
	}

	public String indexData(){
		try {
			Session session = sessionFactory.getCurrentSession();
			FullTextSession fullTextSession = Search.getFullTextSession(session);
			fullTextSession.createIndexer().startAndWait();
			return "Indexed at " + new Date().toString();
		} catch(Exception e) {
			return "Cannot index data. Reason: " + e.getMessage();
		}
	}
}