package natv.ag0.dao;

import natv.ag0.entities.Category;
import natv.ag0.utils.MyNotify;

import java.util.List;

/**
 * Created by nguyen.viet.anhc on 29/11/2016.
 */
public interface CategoryDAO {
	Category getCategoryById(Integer id);
	List<Category> getAllCategory();
	MyNotify createCategory(Category category);
	MyNotify updateCategory(Category category);
	MyNotify deleteCategory(Category category);
}
