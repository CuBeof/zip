package natv.ag0.dao;

import natv.ag0.entities.Vendor;
import natv.ag0.utils.MyNotify;

import java.util.List;

public interface VendorDAO {
	Vendor getVendorById(Integer id);
	MyNotify createVendor(Vendor Vendor);
	MyNotify updateVendor(Vendor Vendor);
	MyNotify deleteVendor(Vendor Vendor);
	public List<Vendor> searchVendor(String keyword, Integer offset, Integer maxResults);
}
