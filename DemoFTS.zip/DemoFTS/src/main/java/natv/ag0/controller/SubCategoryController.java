package natv.ag0.controller;

import natv.ag0.dao.CategoryDAO;
import natv.ag0.dao.SubCategoryDAO;
import natv.ag0.entities.Category;
import natv.ag0.entities.SubCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class SubCategoryController {
    @Autowired
    SubCategoryDAO subCategoryDAO;

    @ResponseBody
    @RequestMapping(value = "/subcategory/{id}", method = RequestMethod.GET)
    public ResponseEntity getSubCategoryById(@PathVariable("id") Integer id) {
        Object result =  subCategoryDAO.getSubCategoryById(id);
        if(null == result) {
            return new ResponseEntity("{}", HttpStatus.OK);
        } else {
            return new ResponseEntity(result, HttpStatus.OK);
        }
    }

	@ResponseBody
	@RequestMapping(value = "/category/{id}/subcategory", method = RequestMethod.GET)
	public ResponseEntity getCategoryById(@PathVariable("id") Integer id) {
		Object result =  subCategoryDAO.getSubCategoryByParentId(id);
		System.out.println("id from controller: " + id);
		if(null == result) {
			return new ResponseEntity( "[]", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

    @ResponseBody
    @RequestMapping(value = "/subcategory/{id}", method = RequestMethod.POST)
    public ResponseEntity updateSubCategory(@RequestBody SubCategory subCategory) {
        Object result =  subCategoryDAO.updateSubCategory(subCategory);
        return new ResponseEntity( result, HttpStatus.OK);
    }

    @ResponseBody
    @RequestMapping(value = "/subcategory", method = RequestMethod.DELETE)
    public ResponseEntity deleteSubCategory(@RequestBody SubCategory subCategory) {
        Object result =  subCategoryDAO.deleteSubCategory(subCategory);
        return new ResponseEntity( result, HttpStatus.OK);
    }
}
