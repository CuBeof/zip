package natv.ag0.controller;

import natv.ag0.dao.OrderDAO;
import natv.ag0.entities.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;

@Controller
public class OrderController {
	@Autowired
	OrderDAO orderDAO;

	@ResponseBody
	@RequestMapping(value = "/order", method = RequestMethod.GET)
	public ResponseEntity getAllOrder() {
		Object result =  orderDAO.getAllOrder();
		System.out.println(result);
		if(null == result) {
			return new ResponseEntity("[]", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/order/{id}", method = RequestMethod.GET)
	public ResponseEntity getOrderById(@PathVariable("id") Integer id) {
		Object result =  orderDAO.getOrderById(id);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/vendor/{id}/order", method = RequestMethod.GET)
	public ResponseEntity getOrderByVendorId(@PathVariable("id") Integer id) {
		Object result =  orderDAO.getOrderByVendorId(id);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/subcategory/{id}/order", method = RequestMethod.GET)
	public ResponseEntity getOrderBySubCategoryId(@PathVariable("id") Integer id) {
		Object result =  orderDAO.getOrderBySubCategoryId(id);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/order", method = RequestMethod.POST)
	public ResponseEntity createOrder(@RequestBody Order Order) {
		System.out.println(Order);
		Object result =  orderDAO.createOrder(Order);
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/order/{id}", method = RequestMethod.DELETE)
	public ResponseEntity deleteOrder(@PathVariable("id") Integer id) {
		Order Order = new Order(id);
		System.out.println(Order.getId());
		Object result =  orderDAO.deleteOrder(Order);
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/order/search/{keyword}", method = RequestMethod.GET)
	public ResponseEntity searchOrder(@PathVariable("keyword") String keyword) {
		try {
			keyword = new String(keyword.getBytes("ISO-8859-1"), "UTF-8");
		} catch (UnsupportedEncodingException e) {
//			Do nothing
		}
		Object result =  orderDAO.searchOrder(keyword, null, null);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/order/search/{keyword}/{page}", method = RequestMethod.GET)
	public ResponseEntity searchOrderWithPage(@PathVariable("keyword") String keyword, @PathVariable("page") Integer page) {
		try {
			keyword = new String(keyword.getBytes("ISO-8859-1"), "UTF-8");
		} catch (UnsupportedEncodingException e) {
//			Do nothing
		}
		Object result =  orderDAO.searchOrder(keyword, page, null);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}
}
