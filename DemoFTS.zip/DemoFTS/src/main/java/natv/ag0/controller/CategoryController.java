package natv.ag0.controller;

import natv.ag0.dao.CategoryDAO;
import natv.ag0.entities.Category;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by nguyen.viet.anhc on 28/11/2016.
 */
@Controller
public class CategoryController {
	@Autowired
	CategoryDAO categoryDAO;

	@ResponseBody
	@RequestMapping(value = "/category", method = RequestMethod.GET)
	public ResponseEntity getAllCategory() {
		Object result =  categoryDAO.getAllCategory();
		System.out.println(result);
		if(null == result) {
			return new ResponseEntity("[]", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/category/{id}", method = RequestMethod.GET)
	public ResponseEntity getCategoryById(@PathVariable("id") Integer id) {
		Object result =  categoryDAO.getCategoryById(id);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/category", method = RequestMethod.POST)
	public ResponseEntity createCategory(@RequestBody Category category) {
		System.out.println(category);
		Object result =  categoryDAO.createCategory(category);
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/category/{id}", method = RequestMethod.DELETE)
	public ResponseEntity deleteCategory(@PathVariable("id") Integer id) {
		Category category = new Category(id);
		System.out.println(category.getId());
		Object result =  categoryDAO.deleteCategory(category);
		return new ResponseEntity( result, HttpStatus.OK);
	}
}
