package natv.ag0.controller;

import natv.ag0.dao.VendorDAO;
import natv.ag0.entities.Vendor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriUtils;

import java.io.UnsupportedEncodingException;

@Controller
public class VendorController {
	@Autowired
	VendorDAO VendorDAO;

	@ResponseBody
	@RequestMapping(value = "/vendor/{id}", method = RequestMethod.GET)
	public ResponseEntity getVendorById(@PathVariable("id") Integer id) {
		Object result =  VendorDAO.getVendorById(id);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/vendor", method = RequestMethod.POST)
	public ResponseEntity createVendor(@RequestBody Vendor Vendor) {
		System.out.println(Vendor);
		Object result =  VendorDAO.createVendor(Vendor);
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/vendor/{id}", method = RequestMethod.DELETE)
	public ResponseEntity deleteVendor(@PathVariable("id") Integer id) {
		Vendor Vendor = new Vendor(id);
		System.out.println(Vendor.getId());
		Object result =  VendorDAO.deleteVendor(Vendor);
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/vendor/search/{keyword}", method = RequestMethod.GET)
	public ResponseEntity searchVendor(@PathVariable("keyword") String keyword) {
		try {
			keyword = new String(keyword.getBytes("ISO-8859-1"), "UTF-8");
		} catch (UnsupportedEncodingException e) {
//			Do nothing
		}
		Object result =  VendorDAO.searchVendor(keyword, null, null);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/vendor/search/{keyword}/{page}", method = RequestMethod.GET)
	public ResponseEntity searchVendorWithPage(@PathVariable("keyword") String keyword, @PathVariable("page") Integer page) {
		try {
			keyword = new String(keyword.getBytes("ISO-8859-1"), "UTF-8");
		} catch (UnsupportedEncodingException e) {
//			Do nothing
		}
		Object result =  VendorDAO.searchVendor(keyword, page, null);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}
}
